﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;


namespace GetInGEAR
{
    public partial class StudentHomePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            /*
          //  Panel panel = new Panel();
           
            for (int recordNumber = 0; recordNumber < 10; recordNumber++)
            {
                // Register the ASCX control with the page and typecast it to the appropriate class ProductDisplay
                //ProductDisplay ctrl = (ProductDisplay)LoadControl("ProductDisplay.ascx");

                // Set properties for the ProductDisplay object
                /// ctrl.ProductID = (String)objDB.GetField("ProductNumber", recordNumber);
                //  ctrl.ProductImage = "images/" + ctrl.ProductID + ".jpg";
                //    ctrl.DataBind();

                // Add the control object to the WebForm's Controls collection
                // Form.Controls.Add(ctrl);
                WebUserControStudentHomePage ctrl = (WebUserControStudentHomePage)LoadControl("WebUserControStudentHomePage.ascx");
                //ctrl.ProductImage = "images/banner.jpg";
                ctrl.DataBind();
                Form.Controls.Add(ctrl);
                Form.Controls.Add(ctrl);
                // DivCircle.InnerHtml = Page.FindControl(WebUserControStudentHomePage);
                placeh.HorizontalAlign = HorizontalAlign.Left;
                placeh.Height = 400;
                placeh.Controls.Add(ctrl);
            }

            placeh.HorizontalAlign = HorizontalAlign.Left;
            placeh.Height = 400;
             */
        }

        protected void btnAppoint_Click(object sender, EventArgs e)
        {
            Response.Redirect("");
        }

        protected void btnsmart_Click(object sender, EventArgs e)
        {
            Response.Redirect("SMARTGOALS.aspx");
        }

        protected void btnselfasss_Click(object sender, EventArgs e)
        {
            Response.Redirect("SelfAssessment.aspx");
            
        }

    }
}